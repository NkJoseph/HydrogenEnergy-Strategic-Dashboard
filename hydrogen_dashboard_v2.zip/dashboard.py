import dash
from dash import dcc, html, Input, Output, State
import dash_bootstrap_components as dbc
import requests
import pandas as pd
import plotly.graph_objects as go

API_URL = "http://localhost:8000"

# Minimalistic theme
external_stylesheets = [dbc.themes.FLATLY]
app = dash.Dash(__name__, external_stylesheets=external_stylesheets, suppress_callback_exceptions=True)
server = app.server

# fetch regions once at start
def fetch_regions():
    try:
        return requests.get(f"{API_URL}/meta/regions", timeout=5).json()
    except Exception:
        return ["Global"]

regions = fetch_regions()

# ------------------------------- Layout ----------------------------------
HEADER = dbc.NavbarSimple(
    brand="Hydrogen Forecast Dashboard",
    color="primary",
    dark=True,
    class_name="mb-4",
)

controls = dbc.Card(
    dbc.CardBody(
        [
            dbc.Row(
                [
                    dbc.Col(
                        [
                            dbc.Label("Region"),
                            dcc.Dropdown(
                                id="region-dd",
                                options=[{"label": r, "value": r} for r in regions],
                                value="Global",
                                clearable=False,
                            ),
                        ],
                        md=3,
                    ),
                    dbc.Col(
                        [
                            dbc.Label("Year"),
                            dcc.Slider(
                                id="year-slider",
                                min=2020,
                                max=2050,
                                step=1,
                                value=2030,
                                tooltip={"placement": "bottom", "always_visible": True},
                            ),
                        ],
                        md=4,
                    ),
                    dbc.Col(
                        [
                            dbc.Label("Target (Mt H₂)"),
                            dbc.Input(id="target-input", type="number", value=430, min=1),
                            dbc.FormText("IEA 430 | IPCC 155 | IRENA 523"),
                        ],
                        md=2,
                    ),
                    dbc.Col(
                        [
                            dbc.Label("Scenario"),
                            dbc.RadioItems(
                                options=[
                                    {"label": "BAU", "value": "BAU"},
                                    {"label": "Optimistic", "value": "Optimistic"},
                                    {"label": "Net-Zero", "value": "Net-Zero"},
                                ],
                                value="BAU",
                                id="scenario-radio",
                                inline=True,
                            ),
                        ],
                        md=3,
                    ),
                ],
                className="g-2",
            ),
            dbc.Row(
                dbc.Col(
                    dbc.Button("Download CSV", id="dl-btn", color="secondary", className="mt-3"),
                    className="text-end",
                )
            ),
        ]
    ),
    class_name="shadow-sm mb-4",
)

app.layout = dbc.Container(
    [
        HEADER,
        controls,
        dcc.Graph(id="forecast-graph", config={"displaylogo": False}),
        dcc.Download(id="csv-download"),
    ],
    fluid=True,
)

# ----------------------------- Helpers -----------------------------------
def _records_to_series(df_records):
    if not df_records:
        return pd.Series(dtype=float)
    df = pd.DataFrame(df_records)
    return pd.Series(df["value"].values, index=df["year"])

def fetch(endpoint: str, method="GET", payload=None):
    url = f"{API_URL}{endpoint}"
    try:
        if method == "GET":
            r = requests.get(url, params=payload, timeout=10)
        else:
            r = requests.post(url, json=payload, timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        raise RuntimeError(str(e)) from e

# ------------------------------ Callbacks ---------------------------------
@app.callback(
    Output("forecast-graph", "figure"),
    Input("region-dd", "value"),
    Input("year-slider", "value"),
    Input("target-input", "value"),
    Input("scenario-radio", "value"),
)
def update_graph(region, year, target, scenario):
    fig = go.Figure()
    # handle backend errors gracefully
    try:
        dl_records = fetch("/forecast", payload={"region": region, "year": year, "scenario": scenario})
        rl_records = fetch("/optimize", method="POST",
                           payload={"region": region, "year": year, "target": target, "scenario": scenario})
        dl_series = _records_to_series(dl_records)
        rl_series = _records_to_series(rl_records)
    except RuntimeError as err:
        fig.add_annotation(text=f"⚠️ {err}", showarrow=False, xref="paper", yref="paper",
                           x=0.5, y=0.5, font=dict(color="crimson"))
        fig.update_layout(template="simple_white")
        return fig

    if not dl_series.empty:
        fig.add_trace(go.Scatter(x=dl_series.index, y=dl_series.values, mode="lines",
                                 name="DL Forecast"))
    if not rl_series.empty:
        fig.add_trace(go.Scatter(x=rl_series.index, y=rl_series.values, mode="lines",
                                 name="RL Pathway"))
    fig.add_hline(y=target, line=dict(dash="dash"), annotation_text=f"Target {target} Mt",
                  annotation_position="top right")
    fig.update_layout(
        template="simple_white",
        xaxis_title="Year",
        yaxis_title="Hydrogen Capacity (Mt)",
        legend=dict(orientation="h", y=-0.2),
    )
    return fig

@app.callback(
    Output("csv-download", "data"),
    Input("dl-btn", "n_clicks"),
    State("region-dd", "value"),
    State("year-slider", "value"),
    State("target-input", "value"),
    State("scenario-radio", "value"),
    prevent_initial_call=True,
)
def download_csv(n, region, year, target, scenario):
    dl_records = fetch("/forecast", payload={"region": region, "year": year, "scenario": scenario})
    rl_records = fetch("/optimize", method="POST",
                       payload={"region": region, "year": year, "target": target, "scenario": scenario})
    df = pd.DataFrame(dl_records + rl_records)
    return dcc.send_data_frame(df.to_csv, f"forecast_{region}_{year}.csv")

if __name__ == "__main__":
    app.run_server(port=8050, debug=True)
