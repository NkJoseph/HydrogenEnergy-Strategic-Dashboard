# Hydrogen Forecast Dashboard

Minimalistic Dash + FastAPI application wrapping DL forecasts and RL optimisation
from existing analysis scripts.

## Quick start (dev)

```bash
# 1. Install deps
pip install -r requirements.txt

# 2. Start REST API
uvicorn api:app --reload --port 8000 &

# 3. Launch Dash front‑end
python dashboard.py
```

FastAPI docs available at http://localhost:8000/docs  
Dash UI available at http://localhost:8050
