from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Literal
import pandas as pd
import importlib
from pathlib import Path
from functools import lru_cache

# ---- constants ----
ROOT = Path(__file__).resolve().parent
MODEL_DIR = ROOT / "pretrained-models"

# dynamic import while preserving original filenames with spaces
global_analysis = importlib.machinery.SourceFileLoader(
    "global_analysis", str(ROOT / "global analysis.py")
).load_module()

regional_analysis = importlib.machinery.SourceFileLoader(
    "regional_analysis", str(ROOT / "regional analysis.py")
).load_module()

app = FastAPI(
    title="Hydrogen Forecast API",
    description="DL + RL hydrogen forecasts",
    version="0.1.0",
)

# allow local Dash front‑end
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class OptimizePayload(BaseModel):
    region: str = Field(..., description='"Global" or region name')
    year: int = Field(..., ge=1900, description="Forecast year")
    target: float = Field(..., gt=0, description="Mt H2 target")
    scenario: Literal["BAU", "Optimistic", "Net-Zero"] = "BAU"

def df_to_records(df: pd.DataFrame, series_name: str):
    df = df.reset_index().rename(columns={df.index.name or "index": "year", df.columns[0]: "value"})
    df["series"] = series_name
    return df.to_dict(orient="records")

@lru_cache(maxsize=128)
def _predict(region: str, year: int, scenario: str):
    if region.lower() == "global":
        df = global_analysis.predict(year, scenario=scenario)
    else:
        df = regional_analysis.predict(region, year, scenario=scenario)
    return df

@lru_cache(maxsize=128)
def _optimize(region: str, year: int, target: float, scenario: str):
    if region.lower() == "global":
        df = global_analysis.optimize_to_target(year, target, scenario=scenario)
    else:
        df = regional_analysis.optimize_to_target(region, year, target, scenario=scenario)
    return df

@app.get("/meta/regions", response_model=List[str])
def get_regions():
    return ["Global"] + regional_analysis.available_regions()

@app.get("/forecast")
def get_forecast(region: str, year: int, scenario: str = "BAU"):
    try:
        df = _predict(region, year, scenario)
    except Exception as e:
        raise HTTPException(status_code=422, detail=str(e))
    return df_to_records(df, "dl_forecast")

@app.post("/optimize")
def post_optimize(payload: OptimizePayload):
    try:
        df = _optimize(payload.region, payload.year, payload.target, payload.scenario)
    except Exception as e:
        raise HTTPException(status_code=422, detail=str(e))
    return df_to_records(df, "rl_pathway")
