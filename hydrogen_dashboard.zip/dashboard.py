import dash
from dash import dcc, html, Input, Output, State
import dash_bootstrap_components as dbc
import requests
import pandas as pd
import plotly.graph_objs as go
from pathlib import Path

API_URL = "http://localhost:8000"

app = dash.Dash(__name__, external_stylesheets=[dbc.themes.FLATLY])
server = app.server

# fetch region list
regions = requests.get(f"{API_URL}/meta/regions").json()

app.layout = dbc.Container(
    [
        dbc.Row(
            dbc.Col(html.H3("Hydrogen Forecast Dashboard"), width="auto", className="my-2")
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Label("Region"),
                        dcc.Dropdown(id="region-dd", options=[{"label": r, "value": r} for r in regions], value="Global"),
                    ],
                    md=3,
                ),
                dbc.Col(
                    [
                        dbc.Label("Year"),
                        dcc.Slider(id="year-slider", min=2020, max=2050, step=1, value=2030, tooltip={"placement": "bottom", "always_visible": True}),
                    ],
                    md=4,
                ),
                dbc.Col(
                    [
                        dbc.Label("Target (Mt H₂)"),
                        dbc.Input(id="target-input", type="number", value=430, min=1),
                        dbc.FormText("IEA 430 | IPCC 155 | IRENA 523"),
                    ],
                    md=2,
                ),
                dbc.Col(
                    [
                        dbc.Label("Scenario"),
                        dbc.RadioItems(
                            options=[
                                {"label": "BAU", "value": "BAU"},
                                {"label": "Optimistic", "value": "Optimistic"},
                                {"label": "Net-Zero", "value": "Net-Zero"},
                            ],
                            value="BAU",
                            id="scenario-radio",
                            inline=True,
                        ),
                    ],
                    md=3,
                ),
            ],
            className="mb-3",
        ),
        dbc.Row(
            dbc.Col(dcc.Graph(id="forecast-graph"), width=12),
        ),
        dbc.Row(
            dbc.Col(
                dbc.Button("Download CSV", id="dl-btn", color="secondary", className="mt-2"),
                width="auto",
            )
        ),
        dcc.Download(id="csv-download"),
    ],
    fluid=True,
)

def fetch_forecast(region, year, scenario):
    resp = requests.get(f"{API_URL}/forecast", params={"region": region, "year": year, "scenario": scenario})
    resp.raise_for_status()
    return pd.DataFrame(resp.json())

def fetch_optimize(region, year, target, scenario):
    resp = requests.post(f"{API_URL}/optimize", json={"region": region, "year": year, "target": target, "scenario": scenario})
    resp.raise_for_status()
    return pd.DataFrame(resp.json())

@app.callback(
    Output("forecast-graph", "figure"),
    Input("region-dd", "value"),
    Input("year-slider", "value"),
    Input("target-input", "value"),
    Input("scenario-radio", "value"),
)
def update_graph(region, year, target, scenario):
    try:
        df_dl = fetch_forecast(region, year, scenario)
        df_rl = fetch_optimize(region, year, target, scenario)
    except Exception as e:
        return go.Figure().add_annotation(text=str(e), showarrow=False)
    fig = go.Figure()
    if not df_dl.empty:
        fig.add_trace(go.Scatter(x=df_dl["year"], y=df_dl["value"], mode="lines", name="DL Forecast"))
    if not df_rl.empty:
        fig.add_trace(go.Scatter(x=df_rl["year"], y=df_rl["value"], mode="lines", name="RL Pathway"))
    # target line
    fig.add_hline(y=target, line=dict(dash="dash", width=1), annotation_text=f"Target {target} Mt", annotation_position="top right")
    fig.update_layout(template="simple_white", xaxis_title="Year", yaxis_title="Hydrogen Capacity (Mt)")
    return fig

@app.callback(
    Output("csv-download", "data"),
    Input("dl-btn", "n_clicks"),
    State("region-dd", "value"),
    State("year-slider", "value"),
    State("target-input", "value"),
    State("scenario-radio", "value"),
    prevent_initial_call=True,
)
def download_csv(n, region, year, target, scenario):
    df_dl = fetch_forecast(region, year, scenario)
    df_rl = fetch_optimize(region, year, target, scenario)
    df = pd.concat([df_dl, df_rl])
    return dcc.send_data_frame(df.to_csv, f"forecast_{region}_{year}.csv")

if __name__ == "__main__":
    app.run_server(port=8050, debug=True)
